<?php
    $html->footer = '<div class="footer"><div class="ads">'.$ads.'</div></div>';
?>